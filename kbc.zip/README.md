# KBC

## Ko Banxa Crorepati

### Obviously, Abik, Dipesh ra Saugat

## What it can do right now
```
- Choose random question from a file
- Display options for that question
- Get the Question's question number
- Get the answer for that question
``` 

## To-Do
```
Create the structure
Take user input and check the answer
Lifeline


Abik is working on:
Timer
```